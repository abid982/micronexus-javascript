/**
 * Diagram 1					     Diagram 2	
Light blue dots have 8 points
Red dot has 6 points
5th ring has 5 points
4th ring has 4 points
3th ring has 3 points
2nd ring has 2 points
1st ring has 1 points

You can only use HTML, CSS and JavaScript to complete this task.
Task (Total Marks: 100)
Make rings as shown in Diagram 1 above
Clicking any rings or dots (red or blue) will alert its points respectively as mentioned above.
Clicking any ring will highlight the clicked ring overall as shown in Diagram 2
Clicking any ring will play beep sound
Store each point in an array
Show total points in a box
Show series of points objects anywhere on screen
Session to run for 120 seconds exactly based on user timezone
Show timer countdown for 120 seconds
Show timer end message and reload the page

Push the code on your public git repo and share the git url for this task. 

Your code and time will be judged according to our requirements for current hiring.

 */

const boxEl = document.querySelector('.box');
const labelTimer = document.querySelector('.logout-timer');

let total = 0;
const arr = [];

// Event delegation
document.querySelector('.container').addEventListener('click', function (e) {
    e.preventDefault();

    console.log(e.target);

    const clicked = e.target.classList.contains('btn');

    if (clicked) {
        console.log('Button was clicked!');
        console.log(clicked);
        // Get src attribute
        // const points = clicked.dataset.points;
        // console.log(clicked.dataset.columns);
        // console.log(points);

        const points = e.target.dataset.points;
        // console.log(points);
        alert(points);

        // Convert string to a number
        const p = Number(points);

        // Highlight the ring
        e.target.style.backgroundColor = 'green';

        // Store each point in an array
        arr.push(p);
        console.log(arr);

        // Sum
        // total += Number(points);
        // console.log(total);

        // Calculate sum
        const total = arr.reduce(function (acc, curr, i, arr) {
           return acc += curr
        }
            , 0);

        // console.log(`Total points: ${total}`);
        // Show total points in a box
        boxEl.textContent = total

        // Show series of points to the console
        console.log('Show series of points');
        arr.forEach(function (curr, i, arr) {
            console.log(curr);
        });
    }
});

const startLogoutTimer = function () {
    // Set time to 120 seconds
    let sec = 120;
    // console.log(time);

    const tick = function () {

        // In each call, print the remaining time to UI
        labelTimer.textContent = `${sec} seconds`;

        // When 0 seconds, stop timer and logout user
        if (sec === 0) {
            // Display timer end message
            labelTimer.textContent = 'Time is finished';

            clearInterval(startTime);

            // Reload the page
            window.location.reload();
        }

        // Decrease 1s
        sec--;
    };

    // Call the timer every second
    tick();
    const startTime = setInterval(tick, 1000);

    return startTime;
};

startLogoutTimer();

// Email: danyaal@mikronexus.com
// We transfer